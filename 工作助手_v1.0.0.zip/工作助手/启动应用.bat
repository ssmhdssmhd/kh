@echo off
echo 正在启动工作助手...
python work_assistant.py
pause
