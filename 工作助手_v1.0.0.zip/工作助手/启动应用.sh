#!/bin/bash
echo "正在启动工作助手..."
python3 work_assistant.py
